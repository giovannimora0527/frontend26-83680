package com.uniminuto.clinica.apicontroller;

import com.uniminuto.clinica.api.MascotaApi;
import com.uniminuto.clinica.entity.Mascota;
import com.uniminuto.clinica.models.MascotaRq;
import com.uniminuto.clinica.models.MiRespuestaRS;
import com.uniminuto.clinica.service.MascotaService;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MascotaApiController implements MascotaApi {

    @Autowired
    private MascotaService mascotaService;

    @Override
    public ResponseEntity<List<Mascota>> listarMascotas() throws BadRequestException {
        return ResponseEntity.ok(mascotaService.listarMascotas());
    }

    @Override
    public ResponseEntity<List<Mascota>> buscarMascotasPorCliente(Long clienteId) throws BadRequestException {
        return ResponseEntity.ok(mascotaService.listarMascotasPorCliente(clienteId));
    }

    @Override
    public ResponseEntity<List<Mascota>> buscarMascotasPorRaza(Integer razaId) throws BadRequestException {
        return ResponseEntity.ok(mascotaService.listarMascotasPorRaza(razaId));
    }

    @Override
    public ResponseEntity<MiRespuestaRS> guardarMascota(MascotaRq mascotaRq) throws BadRequestException {
        return ResponseEntity.ok(mascotaService.guardarMascota(mascotaRq));
    }

    @Override
    public ResponseEntity<MiRespuestaRS> actualizarMascota(MascotaRq mascotaRq) throws BadRequestException {
        return ResponseEntity.ok(mascotaService.actualizarMascota(mascotaRq));
    }
}
